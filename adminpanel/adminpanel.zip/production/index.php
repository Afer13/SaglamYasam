<?php include 'header.php'; ?>

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>İDARƏETMƏ PANELİ</h3>
              </div>

            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">

                    <ul style="padding-left: 50px;" class="nav navbar-right panel_toolbox">
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>

                  <div class="x_content">
                      PDOporto websayıtındakı parametirləri(logo,telefon nömrəsi,fax nömrəsi,email ünvanı,google map,mesaj göndərmə elementləri,şirkət ünvanı,google axtarış nəticəsi və s.) və slaydları,websayt haqqında məlumatı,xəbərləri,filialları və s. bu İdarəetmə panelindən dəyişə bilərsiniz ...
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


        <?php include 'footer.php'; ?>