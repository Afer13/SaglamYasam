<!-- sidebar menu -->
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <ul class="nav side-menu">
      <li><a href="index.php"><i class="fa fa-home"></i> Ana Menu</a></li>
      <li><a href="sifaris.php"><i class="fa fa-question"></i> Sifarişlər</a></li>
    </ul>
  </div>


</div>
            <!-- /sidebar menu -->