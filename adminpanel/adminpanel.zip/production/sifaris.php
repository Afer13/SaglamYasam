<?php 
error_reporting(0);
include 'header.php';


$sifarisSorgu=$db->prepare("select * from sifarisler order by sifaris_tarix desc");

$sifarisSorgu->execute();
?>
<head>
  <script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>
</head>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Sifarşlər</h3>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div align="right" class="x_title">
                    <h2>Sifariş Tənzimləmə</h2>  
                      <a href="sifariselaveet.php"><button style="margin-right: 10px;width: 20%;" type="submit" class="btn btn-success">Sifariş Əlavə Et</button></a>               
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <?php if($_GET['durumY']=="ok"){ ?>
                    <p style="color: green;">Məlumat uğurla yeniləndi...</p>
                  <?php } else if($_GET['durumY']=="no"){ ?>
                    <p style="color: red;">Məlumat yenilənə bilmədi !</p>
                    <?php } elseif($_GET['durumE']=="ok"){ ?>
                    <p style="color: green;">Məlumat əlavə edildi...</p>
                  <?php } else if($_GET['durumE']=="no"){ ?>
                    <p style="color: red;">Məlumat əlavə edilə bilmədi !</p>
                  <?php } elseif($_GET['durumS']=="ok"){ ?>
                    <p style="color: green;">Məlumat silindi ...</p>
                  <?php } else if($_GET['durumS']=="no"){ ?>
                    <p style="color: red;">Məlumat silinə bilmədi !</p>
                  <?php }else{ ?>
                  <?php } ?>
                  

                  <div style="margin-top: 20px;" class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title"># </th>
                            <th class="column-title">Ad </th>
                            <th class="column-title">Şəhər </th>
                            <th class="column-title">Telefon </th>
                            <th class="column-title">Sifariş Tarixi </th>
                            <th class="column-title">Sifariş Sayı </th>
                            
                            <th style="width: 80px;" class="column-title"></th>
                            <th style="width: 80px;" class="column-title"></th>
                          </tr>
                        </thead>

                        
                        <tbody>
                          <?php 
                          while ($sifarisCek=$sifarisSorgu->fetch(PDO::FETCH_ASSOC)) { ?>
                          <tr class="even pointer">
                            <td class=" "><?php echo $sifarisCek['sifaris_id'];; ?></td>
                            <td class=" "><?php echo $sifarisCek['sifaris_ad']; ?></td>
                            <td class=" "><?php echo $sifarisCek['sifaris_seher']; ?> </td>
                            <td class=" "><?php echo $sifarisCek['sifaris_telefon']; ?> </td>
                            <td class=" "><?php echo $sifarisCek['sifaris_tarix']; ?> </td>

                            <?php 
                            $sifarisSay=$db->prepare("select * from sifarisler where sifaris_telefon=:sifaris_telefon");
                            $sifarisSay->execute(array(
                              'sifaris_telefon'=>$sifarisCek['sifaris_telefon']
                            ));
                            $say = $sifarisSay->rowCount();
                             ?>
                            <td class=" "><?php echo $say; ?> </td>

                            <td class=" "><a href="sifarisyenile.php?sifaris_id=<?php echo $sifarisCek['sifaris_id']; ?>"><button style="margin-top: 15px;width: 100px;" type="submit" class="btn btn-primary "><i class="fa fa-pencil"> Yenilə</i></button></a></td>

                            <td class=" "><a href="emeliyyat.php?sifaris_id=<?php echo $sifarisCek['sifaris_id']; ?>"><button style="margin-top: 15px;width: 100px;" type="submit" class="btn btn-danger "><i class="fa fa-trash"> Sil</i></button></a></td>

                          </tr>
                        <?php } ?>
                        </tbody>
                      </table>
                    </div>


                  </div> 
                </div>

              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->


        <?php include 'footer.php'; ?>