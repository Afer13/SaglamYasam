<?php 
include 'baglan.php';
//----------==========--------------LogIn-------------------------========------
if(isset($_POST['giriset']))
{
	echo $istifadeci_ad=$_POST['istifadeci_ad'];
	echo $istifadeci_sifre=$_POST['istifadeci_sifre'];
	
}
?>