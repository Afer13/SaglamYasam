<?php 
try {
	$db=new PDO("mysql:host=localhost:3308;dbname=saglamyasam",'root','13545762aR');
	//echo "ok";
} catch (PDOException $e) {
	echo $e->getMesssage();
}
?>